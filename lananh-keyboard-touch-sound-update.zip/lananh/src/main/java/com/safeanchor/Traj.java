package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;

/** Predicts the local player's held projectile path and marks its first predicted impact. */
public final class Traj {
    private Traj() {}

    public static class Result {
        public final List<Vec3d> pts = new ArrayList<>();
        /** Block expected to be hit first, or the block containing the entity impact. */
        public BlockPos land;
        public PlayerEntity hit;
    }

    private record Physics(double speed, double gravity, double drag, double pitchOffset) {}

    public static Result compute(MinecraftClient mc, float tickDelta) {
        if (mc == null || mc.player == null || mc.world == null) return null;
        var player = mc.player;
        var world = mc.world;
        ItemStack stack = player.getMainHandStack();
        Physics physics = physicsFor(stack, player);
        if (physics == null) return null;

        double yaw = Math.toRadians(player.getYaw());
        double pitch = Math.toRadians(player.getPitch() + physics.pitchOffset());
        double horizontal = Math.cos(pitch);
        Vec3d direction = new Vec3d(-Math.sin(yaw) * horizontal, -Math.sin(pitch), Math.cos(yaw) * horizontal).normalize();
        Vec3d velocity = direction.multiply(physics.speed())
            .add(player.getVelocity().x, player.isOnGround() ? 0 : player.getVelocity().y, player.getVelocity().z);
        Vec3d position = player.getCameraPosVec(tickDelta).add(0, -0.1, 0);

        Result result = new Result();
        result.pts.add(position);
        for (int step = 0; step < 200; step++) {
            Vec3d next = position.add(velocity);

            // Find the first solid-block impact so entities behind a wall are not highlighted.
            var blockHit = world.raycast(new RaycastContext(position, next,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
            Vec3d end = blockHit.getType() == HitResult.Type.BLOCK ? blockHit.getPos() : next;

            PlayerEntity firstPlayer = null;
            Vec3d firstPlayerHit = null;
            double nearest = Double.MAX_VALUE;
            for (PlayerEntity other : world.getPlayers()) {
                if (other == player || other.isSpectator() || !other.isAlive()) continue;
                Box bounds = other.getBoundingBox().expand(0.3);
                var entityHit = bounds.raycast(position, end);
                if (entityHit.isPresent()) {
                    double distance = position.squaredDistanceTo(entityHit.get());
                    if (distance < nearest) {
                        nearest = distance;
                        firstPlayer = other;
                        firstPlayerHit = entityHit.get();
                    }
                }
            }

            if (firstPlayer != null) {
                result.hit = firstPlayer;
                result.land = BlockPos.ofFloored(firstPlayerHit);
                result.pts.add(firstPlayerHit);
                return result;
            }
            if (blockHit.getType() == HitResult.Type.BLOCK) {
                result.land = blockHit.getBlockPos();
                result.pts.add(blockHit.getPos());
                return result;
            }

            result.pts.add(next);
            position = next;
            velocity = velocity.multiply(physics.drag()).add(0, -physics.gravity(), 0);
            if (position.y < world.getBottomY() - 10) break;
        }
        return result;
    }

    private static Physics physicsFor(ItemStack stack, net.minecraft.entity.player.PlayerEntity player) {
        if (stack.isOf(Items.ENDER_PEARL) || stack.isOf(Items.SNOWBALL) || stack.isOf(Items.EGG))
            return new Physics(1.5, 0.03, 0.99, 0);
        if (stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION))
            return new Physics(0.5, 0.05, 0.99, -20);
        if (stack.isOf(Items.EXPERIENCE_BOTTLE))
            return new Physics(0.7, 0.07, 0.99, -20);
        if (stack.isOf(Items.WIND_CHARGE))
            return new Physics(1.5, 0.0, 0.99, 0);
        if (stack.isOf(Items.TRIDENT) && player.isUsingItem() && player.getActiveItem().isOf(Items.TRIDENT)) {
            // A trident is only thrown after charging; show the prediction while it is being charged.
            int useTicks = player.getItemUseTime();
            if (useTicks < 10) return null;
            return new Physics(2.5, 0.05, 0.99, 0);
        }
        if (stack.isOf(Items.BOW) && player.isUsingItem() && player.getActiveItem().isOf(Items.BOW)) {
            float charge = player.getItemUseTime() / 20f;
            charge = (charge * charge + charge * 2f) / 3f;
            if (charge > 1f) charge = 1f;
            if (charge < 0.1f) return null;
            return new Physics(charge * 3.0, 0.05, 0.99, 0);
        }
        return null;
    }
}
