package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;

/** Small client-side click sound for keyboard presses and in-world touch/mouse clicks. */
public final class KeySound {
    private KeySound() {}

    public static void playKey(int key) {
        Config c = Config.I;
        if (c == null || !c.keySoundEnabled || !c.keySoundKeyboard || c.keySoundVolume <= 0.001) return;
        // Slight pitch variation makes repeated key taps sound less mechanical.
        float pitch = 0.94f + (Math.floorMod(key, 7) * 0.02f);
        play(c.keySoundVolume, pitch);
    }

    public static void playMouse() {
        Config c = Config.I;
        if (c == null || !c.keySoundEnabled || !c.keySoundMouse || c.keySoundVolume <= 0.001) return;
        play(c.keySoundVolume, 1.0f);
    }

    public static void playTest() {
        Config c = Config.I;
        if (c == null) return;
        play((float)Math.max(0.0, Math.min(0.25, c.keySoundVolume)), 1.0f);
    }

    private static void play(float volume, float pitch) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getSoundManager() == null) return;
        mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, pitch, volume));
    }
}
