package com.safeanchor.mixin;

import com.safeanchor.KeySound;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void lananh$touchSound(long window, int button, int action, int mods, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        // Menu buttons already have Minecraft's own UI click sound; add custom sound only in-world.
        if (action == GLFW.GLFW_PRESS && mc != null && mc.currentScreen == null) KeySound.playMouse();
    }
}
