# LAN ANH CLIENT PVP & RAID — Fabric 1.21.4

Source project for Minecraft Java 1.21.4 / Fabric / Java 21. This is a client-side mod source project, not a prebuilt `.jar`.

## Features included in this source
- Existing PvP modules: Elytra Mace, Crystal/Pearl helper, Safe Anchor, aim/FOV options.
- Player/mob/storage ESP, tracers, block ESP, radar and player counter.
- Schematic helper/printer.
- **New Raid HUD**: toggleable XYZ coordinates, dimension name, inventory Totem count and armor durability percentages.
- Pink HUD styling and persistent config at `.minecraft/config/safeanchor.json`.

## Build on GitHub (phone-friendly)
1. Extract this ZIP and upload the **contents** to a new GitHub repository (the `.github/workflows/build.yml` folder must be included).
2. Open **Actions** and allow workflows if GitHub asks.
3. Run **Build Fabric Mod** (or push a commit to trigger it).
4. Open the completed run, scroll to **Artifacts**, and download `LanAnhClient-1.21.4-Fabric`.
5. Extract the artifact ZIP; place the mod JAR in `.minecraft/mods` with Fabric Loader for 1.21.4 and a compatible Fabric API.

The workflow uses Gradle installed by GitHub Actions; no Gradle wrapper is included in this source ZIP.

## Default keybinds
- Right Shift: main menu
- R: Elytra Mace toggle
- G: Safe Anchor toggle
- V: Anchor action
- P: schematic helper
- B: aim module

Keybinds can be changed in Minecraft Controls. Module behavior depends on the Minecraft version, server rules and the state of this beta source. Build success is not the same as in-game testing; test in a local world first and back up worlds/configs before experimenting.

## Compatibility
Minecraft Java 1.21.4, Fabric Loader 0.16+, Java 21, Fabric API 0.119.2+1.21.4. No shader is bundled.



### Elytra Mace Loop update (2.3.1)
- Added the `Bay lên lại sau cú đập (loop)` option in the Elytra Mace menu (enabled by default).
- After an eligible falling mace attack, the state machine now attempts to re-equip Elytra, resume gliding, use at most one firework during that recovery, and gain altitude before starting another dive.
- This is best-effort client automation: the server may reject glide/attack actions, inventory swaps can be delayed, and the logic is not in-game tested. Keep the loop disabled or test in a private world if it behaves unexpectedly.

### Projectile Prediction (update)
- Predicts the local player's held Ender Pearl, snowball, egg, splash/lingering potion, experience bottle and Wind Charge trajectory.
- Shows a predicted first-impact path and marks the predicted impact block; if a player is intersected first, highlights that player and marks the approximate impact position.
- Bow prediction is shown while charging. Trident prediction is shown after its charge reaches the throw threshold.
- This is a client-side estimate, not a guarantee: server latency, exact projectile physics, movement, and server modifications can shift the real impact. Test on a private world first.


## Bản bổ sung World Info HUD
- Thêm HUD thông tin thế giới: FPS, ping (nếu server cung cấp), biome, tọa độ chunk và RAM Java đang dùng/tối đa.
- Có công tắc riêng trong mục Raid HUD để tắt từng dòng.
- Đây là thay đổi mã nguồn; chưa xác nhận build thành công hoặc thử trong Minecraft.


## Fix Lag + Shader menu update

Đã thêm trang `Fix Lag + Shader` vào menu chính. Ba preset (FIX LAG MẠNH / CÂN BẰNG / ƯU TIÊN HÌNH ẢNH) điều chỉnh các tính năng render của addon như ESP, radar, trajectory và schematic ghost, đồng thời chỉnh tầm hiển thị để giảm tải. Các thanh trượt cho phép tự chỉnh.

Trang hướng dẫn Shader ghi các bước chỉnh trong Iris. Lưu ý: addon này không thay đổi trực tiếp các thông số nội bộ của shader pack; các tùy chọn shader phải chỉnh trong menu Iris/Shader Pack Settings, nếu shader đó hỗ trợ. Shader không tự làm game nhẹ hơn — shader thường làm tăng tải GPU; shader nhẹ và cấu hình thấp mới có thể giữ FPS tốt hơn.

Chưa xác nhận build thành công hoặc thử trong Minecraft. Đây là mã nguồn, không phải file JAR đã build.


## Âm thanh bàn phím / chạm (bổ sung)
- Menu chính → “ÂM THANH BÀN PHÍM / CHẠM”.
- Bật/tắt tiếng khi nhấn phím (bao gồm WASD) và khi chạm/nhấn chuột trong thế giới game.
- Thanh âm lượng từ 0.00 đến 0.25; mặc định 0.08 để tiếng nhỏ. Có nút “Thử âm thanh”.
- Âm thanh là tiếng UI click của Minecraft; các nút menu đã có âm thanh mặc định nên không thêm tiếng thứ hai khi bấm menu.
- Bản này cần được build/test bằng Gradle + Java 21 trước khi dùng trong game.
